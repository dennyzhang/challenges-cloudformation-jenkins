jenkins-demo Cookbook
================
Setup and configure jenkins for mdm project

KITCHEN_YAML=.kitchen.docker.yml kitchen test
KITCHEN_YAML=.kitchen.vagrant.yml kitchen test
